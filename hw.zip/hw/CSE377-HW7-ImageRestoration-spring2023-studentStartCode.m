%Restore DIC images using the sparsity-constrained quadratic optimization

%Zhaozheng Yin, spring 2023, Stony Brook

clc; clear all; close all;

%read image
g = double(imread("DICImage.tif"));
[nrows, ncols] = size(g); N = nrows*ncols;

%flatten the image (i.e., g <-- g-c in the lecture note)
[xx, yy] = meshgrid(1:ncols, 1:nrows);
xx = xx(:); yy = yy(:);
X = [ones(N,1), xx, yy, xx.^2, xx.*yy, yy.^2];
p = X\g(:); %p = (X'*X)^(-1)*X'*im(:);
g = reshape(g(:)-X*p,[nrows,ncols]);
g = g/max(abs(g(:))); %image value in [-1,1]
figure(1); imshow(g,[]);title('Input DIC image');       

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%compute the H (imaging model), L (smooth) matrice
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tt = cputime;
%get the differential kernel for H
sigma = 1; %sigma in the first-derivative-of-Gaussian kernel
theta = 225*pi/180+pi;%this parameter is related to this given image's microscope parameter
radius = max(2*ceil(sigma),1);  
diameter = 2*radius + 1;
[xx,yy] = meshgrid(-radius:radius,-radius:radius);
tmp = exp(-0.5*(xx.^2 + yy.^2)/sigma^2);    
h_kernel = -(cos(theta)*xx+sin(theta)*yy).*tmp;        
h_kernel = h_kernel/sum(abs(h_kernel(:)));

%build the sparse H matrix
nzidx = abs(h_kernel(:)) > 0.001; %save memory and speed up by ignoring small elements
inds = reshape(1:N, nrows, ncols);
inds_pad = padarray(inds,[radius radius],'symmetric'); %deal with the boundary
row_inds = repmat(1:N, sum(nzidx), 1);
col_inds = im2col(inds_pad, [diameter,diameter], 'sliding'); %slide col and then row
col_inds = col_inds(repmat(nzidx, [1,N]));
vals = repmat(h_kernel(nzidx), N, 1);
H = sparse(row_inds(:), col_inds(:), vals, N, N);     

%get the smooth kernel for L
hwid = 1; wid = 2*hwid + 1; nsz = wid^2;
D = -ones(wid,wid)/(nsz-1);
D(hwid+1,hwid+1) = 1; 

%build the sparse L matrix
inds = reshape(1:N, nrows, ncols);
inds_pad = padarray(inds,[hwid hwid],'symmetric');
row_inds = repmat(1:N,nsz,1);
col_inds = im2col(inds_pad,[wid,wid],'sliding'); %slide col and then row
vals = repmat(D(:),N,1);
L = sparse(row_inds(:), col_inds(:), vals, N, N);               
fprintf('get H and L: %.3f seconds\n',cputime-tt);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%restoration by the sparsity constrained quadratic optimization
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%parameters used in the optimization
gamma = ; %used in reweighting
w_sparsity = ; %sparsity weight
w_smooth = ; %smoothness weight
tol = ; %convergence criterion 
maxiter = ; %convergence criterion

%Your implementation below:
